# Health Ka Safar WebView app - no custom ProGuard rules required.
