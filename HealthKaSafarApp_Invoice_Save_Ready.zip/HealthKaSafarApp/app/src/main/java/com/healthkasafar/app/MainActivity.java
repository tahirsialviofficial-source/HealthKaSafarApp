package com.healthkasafar.app;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.JavascriptInterface;
import android.webkit.MimeTypeMap;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;
import android.widget.Toast;
import android.util.Base64;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final String HOME = "https://healthkasafar.blogspot.com/";
    private WebView webView;
    private ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.webView);
        progressBar = findViewById(R.id.progressBar);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setSupportMultipleWindows(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);

        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);

        webView.addJavascriptInterface(new AndroidBridge(this), "AndroidApp");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String host = uri.getHost();
                if (host != null && (host.equals("healthkasafar.blogspot.com") || host.endsWith(".blogspot.com"))) {
                    return false;
                }
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                } catch (ActivityNotFoundException ignored) { }
                return true;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                if (url != null && url.startsWith(HOME)) {
                    installDownloadBridge(view);
                }
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                progressBar.setProgress(newProgress);
                progressBar.setVisibility(newProgress >= 100 ? ProgressBar.GONE : ProgressBar.VISIBLE);
            }
        });

        webView.setDownloadListener(new DownloadListener() {
            @Override
            public void onDownloadStart(String url, String userAgent, String contentDisposition,
                                        String mimeType, long contentLength) {
                try {
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                    startActivity(intent);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "فائل محفوظ نہیں ہو سکی", Toast.LENGTH_SHORT).show();
                }
            }
        });

        if (savedInstanceState == null) {
            webView.loadUrl(HOME);
        } else {
            webView.restoreState(savedInstanceState);
        }
    }

    private void installDownloadBridge(WebView view) {
        String js = "javascript:(function(){" +
                "if(window.__hksDownloadBridge)return;window.__hksDownloadBridge=true;" +
                "document.addEventListener('click',function(e){" +
                "var a=e.target.closest&&e.target.closest('a[download]');" +
                "if(!a)return;var href=a.href||'';var name=a.getAttribute('download')||'Health-Ka-Safar-Invoice';" +
                "if(href.indexOf('blob:')===0){e.preventDefault();fetch(href).then(function(r){return r.blob()}).then(function(b){" +
                "var fr=new FileReader();fr.onloadend=function(){AndroidApp.saveBase64File(name,b.type||'image/png',fr.result.split(',')[1]);};fr.readAsDataURL(b);" +
                "}).catch(function(){AndroidApp.toast('فائل محفوظ نہیں ہو سکی');});}" +
                "else if(href.indexOf('data:')===0){e.preventDefault();var p=href.indexOf(',');var meta=href.substring(5,p);var data=href.substring(p+1);var mime=(meta.split(';')[0]||'application/octet-stream');AndroidApp.saveDataUrl(name,mime,data,meta.indexOf(';base64')>=0);}" +
                "},true);" +
                "})();void(0);";
        view.evaluateJavascript(js, null);
    }

    public void shareFile(File file, String mimeType) {
        Uri uri = androidx.core.content.FileProvider.getUriForFile(this, getPackageName()+".fileprovider", file);
        Intent share = new Intent(Intent.ACTION_SEND);
        share.setType(mimeType != null && !mimeType.isEmpty() ? mimeType : "application/octet-stream");
        share.putExtra(Intent.EXTRA_STREAM, uri);
        share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(Intent.createChooser(share, "Invoice Share کریں"));
    }

    public class AndroidBridge {
        private final Context context;
        AndroidBridge(Context context) { this.context = context; }

        @JavascriptInterface
        public void toast(final String message) {
            runOnUiThread(() -> Toast.makeText(context, message, Toast.LENGTH_SHORT).show());
        }

        @JavascriptInterface
        public void saveBase64File(String filename, String mimeType, String base64) {
            try {
                byte[] data = Base64.decode(base64, Base64.DEFAULT);
                saveBytes(filename, mimeType, data);
            } catch (Exception e) {
                toast("فائل محفوظ نہیں ہو سکی");
            }
        }

        @JavascriptInterface
        public void saveDataUrl(String filename, String mimeType, String data, boolean isBase64) {
            try {
                byte[] bytes = isBase64 ? Base64.decode(data, Base64.DEFAULT) : Uri.decode(data).getBytes("UTF-8");
                saveBytes(filename, mimeType, bytes);
            } catch (Exception e) {
                toast("فائل محفوظ نہیں ہو سکی");
            }
        }

        private void saveBytes(String filename, String mimeType, byte[] bytes) throws IOException {
            String safeName = filename == null || filename.trim().isEmpty() ? "Health-Ka-Safar-Invoice" : filename.trim();
            if (!safeName.contains(".")) {
                String ext = MimeTypeMap.getSingleton().getExtensionFromMimeType(mimeType);
                safeName += "." + (ext == null ? "png" : ext);
            }
            if (android.os.Build.VERSION.SDK_INT >= 29) {
                android.content.ContentValues values = new android.content.ContentValues();
                values.put(MediaStore.Downloads.DISPLAY_NAME, safeName);
                values.put(MediaStore.Downloads.MIME_TYPE, mimeType == null ? "application/octet-stream" : mimeType);
                values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                if (uri == null) throw new IOException("insert failed");
                try (java.io.OutputStream out = getContentResolver().openOutputStream(uri)) {
                    if (out == null) throw new IOException("open failed");
                    out.write(bytes);
                }
            } else {
                File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                if (!dir.exists() && !dir.mkdirs()) throw new IOException("mkdir failed");
                File file = new File(dir, safeName);
                try (FileOutputStream out = new FileOutputStream(file)) { out.write(bytes); }
            }
            toast("Invoice محفوظ ہو گیا");
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
